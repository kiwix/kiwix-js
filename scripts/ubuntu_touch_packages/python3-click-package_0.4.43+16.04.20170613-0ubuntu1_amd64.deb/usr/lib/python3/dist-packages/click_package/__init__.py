# Marker to help resolve unfortunate name clash between this package and
# https://pypi.python.org/pypi/click.
_CLICK_IS_A_PACKAGING_FORMAT_ = 1
